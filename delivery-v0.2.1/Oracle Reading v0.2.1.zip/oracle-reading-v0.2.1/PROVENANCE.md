# Source and authorship

Created by stunspot / Collaborative Dynamics, 2026. Oracle Reading 0.2.1 carries Selene Astra's practiced encounter into a host-AI skill and accompanying visual table.

The owner supplied Oracle of Celestial Whispers — Selene Astra T4 v1 and AI Astrology Knowledge Base. A separate model-role specialist read both whole and was consulted through an actual three-turn exchange about reception, instrument choice, performed readings, visual attention and disagreement. This is model-role expert consultation, not an independent human interview or empirical validation of divination. The earlier reconstructed Q&A was not that consultation.

Original supplied files remain unchanged in private owner custody and are excluded from public/runtime cargo. selene-practice.md is a named operative runtime derivative; astrology-knowledge-base.md is original domain prose derived from the complete knowledge source. Caller identity and active encounter contract govern source use. Optional methods never mandate missing chart data, and source claims of universal delivery/statistical validation do not overrule evidence or the seeker.

The tarot picture collection uses unmodified 330px Wikimedia Commons thumbnails from the consistent [Rider-Waite-Smith Pam-A scan set uploaded by TaionWC](https://commons.wikimedia.org/wiki/Category:Rider-Waite-Smith_tarot_deck_(TaionWC)). Artwork: Pamela Colman Smith. All 78 description pages were checked through Commons image metadata as Public domain; per-card page, image URL, source URL and hash are in skills/oracle-reading/assets/cards/manifest.json. Historical art is public domain, distinct from MIT code and newly authored text. The product avatar remains original OpenAI image generation.

Catalog associations are original contemporary commentary, not a commercial deck guidebook, modern I Ching translation or definitive ancient rune rite. Rune practice is modern Elder Futhark reflection. I Ching mapping is independently checked against Unicode figures; detailed line reading uses the chosen actual text. [Waite's Pictorial Key](https://sacred-texts.com/tarot/pkt/) and [Legge's Book of Changes](https://sacred-texts.com/ich/ic01.htm) inform vocabulary/order; no source passages from them are reproduced.


The shared face-down card back, skills/oracle-reading/assets/card-back.jpg, is original artwork made with OpenAI built-in image generation on 2026-10-05. The generated raster was resized and JPEG-encoded to 330 × 570 for offline/inline display; no artwork was drawn by code. Its celestial pattern identifies a card back and conveys no hidden-card identity or orientation. Generation prompt is preserved in skills/oracle-reading/assets/card-back-source.md.

Current0.2.1 is a distinct installable update carrying the accepted0.2.0 practice and native-icon repair. Original Selene expert consultation, source/art checks and prior reading/cast/continuity/privacy/icon observations retain their original cutoffs. No new consultation, model efficacy or nativeMac qualification is claimed.
