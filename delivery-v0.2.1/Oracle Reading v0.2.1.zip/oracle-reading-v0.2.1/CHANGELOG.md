# Changelog

## 0.2.1 — 2026-10-12

Distinct installable update carrying the accepted reading/table/native-icon repair. Current complete and standalone package identities and provenance version advance together; all operative code, Selene practice and artwork remain unchanged. Prior evidence retains its original scope.

## 0.2.0 — 2026-10-05

2026-10-12 presentation repair: recognizable browser/self-contained reading icons and native entry bindings for the existing table; cosmetic failures preserve launch/rendering. Native macOS execution remains unverified.

Presentation repair: unrevealed tarot cards now show an original decorated card back in inline, standalone and hosted tables.

The existing AI now conducts the reading and operates a quiet accompanying table. Selene's performed expert consultation informs operative reception, symbolic synthesis and visual timing. Added matching art for all 78 cards, four visual methods, staged reveal/focus, canonical cast continuity, quiet/clear, self-contained inline/standalone output and AI-generated public table links. Replaces the self-service studio. Existing v1 casts can be rendered; journal storage is not automatically migrated.

## 0.1.1 — 2026-10-05

Exclusive local binding, available-port fallback and opening the actual bound address.

## 0.1.0 — 2026-10-05

Initial assistant skill and self-service studio. Superseded encounter frame.

